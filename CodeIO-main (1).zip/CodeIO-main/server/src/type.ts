export interface TeacherProps {
	
}

export interface UserProps {
	
}