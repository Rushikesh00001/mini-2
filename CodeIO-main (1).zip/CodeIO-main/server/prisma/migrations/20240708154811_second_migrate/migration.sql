-- DropIndex
DROP INDEX "Score_studentId_key";
