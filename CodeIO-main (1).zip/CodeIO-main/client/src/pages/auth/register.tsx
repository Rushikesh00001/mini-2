import AuthForm from "./authForm";

const Register = () => {
  return (
    <div className="w-full h-full flex flex-col justify-center items-center"><AuthForm login={false}/></div>
  )
};

export default Register;
