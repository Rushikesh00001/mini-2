import AuthForm from "./authForm";

const ForgotPassword = () => {
  return <AuthForm login={false}/>;
};

export default ForgotPassword;
