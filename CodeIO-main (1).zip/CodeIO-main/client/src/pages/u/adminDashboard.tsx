const AdminDashboard = () => {
  return <div>This is AdminDashboard</div>;
};

export default AdminDashboard;
