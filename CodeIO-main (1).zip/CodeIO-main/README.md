Cd into client and server individually and npm i all dependencies

then run npm run dev in a client terminal and one in a server terminal
